<?php
require_once('conn.php');

//pagination Start

// define how many results you want per page
$results_per_page = 5;

// find out the number of results stored in database
$sql="SELECT * from personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id";
$result = mysqli_query($conn, $sql);
$number_of_results = mysqli_num_rows($result);

// determine number of total pages available
$number_of_pages = ceil($number_of_results/$results_per_page);

// determine which page number visitor is currently on
if (!isset($_GET['page'])) {
  $page = 1;
} else {
  $page = $_GET['page'];
}

// determine the sql LIMIT starting number for the results on the displaying page
$this_page_first_result = ($page-1)*$results_per_page;

// retrieve selected results from database and display them on page
$sql='SELECT * FROM  personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id LIMIT ' . $this_page_first_result . ',' . $results_per_page;
$result = mysqli_query($conn, $sql);


 echo '<table id="list">
	    <thead>
            <tr>
				<th><input type="checkbox"></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<th>Adress 1</th>
				<th>Adress 2</th>
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
       <tbody id="tabledata">';
        while($row = mysqli_fetch_array($result)) {
        echo' 	
		     <tr>
		    	<td><input type="checkbox"></td>
			    <td>'.$row["first_name"].'</td>
		   		<td>'.$row["last_name"].'</td>
		   		<td>'.$row["email"].'</td>  	
		   		<td>'.$row["gender"].'</td>
		   		<td>'.$row["mobile_no"].'</td>
		   		<td>'.$row["addr1"].'</td> 
		   		<td>'.$row["addr2"].'</td>
		   		<td>'.$row["country_name"].'</td>
		   		<td>'.$row["state_name"].'</td> 
		   		<td>'.$row["city"].'</td>
		   		<td>'.$row["pincode"].'</td>
		   		<td><a href=" personal_detail.php?id= '.$row['id'].' "><img src="edit.png" height="20px" width="20px"></a></td>
		   		<td><img src="delete.png" height="20px" width="20px"></td>
		    </tr> ';}
echo' </tbody> </table>';

echo      ' <div class="pagediv">';
				for ($page=1;$page<=$number_of_pages;$page++) {
				  echo '<a class="pagelist" href="index.php?page=' . $page . '">' . $page . '</a> ';
				}	
	 echo  '</div>';
 ?>