<?php

$conn=mysqli_connect("localhost","root","","task_pd");

?>