<?php
require_once('conn.php');
session_start();
// echo $_SESSION['page'];

//pagination Start

// define how many results you want per page
$results_per_page = 5;

// find out the number of results stored in database
$sql="SELECT * from personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id";
$result = mysqli_query($conn, $sql);
$number_of_results = mysqli_num_rows($result);
// $_GET["rowcount"]=mysqli_num_rows($result);

// determine number of total pages available
$number_of_pages = ceil($number_of_results/$results_per_page);

// determine which page number visitor is currently on
if (isset($_GET['page'])) {

   $page = $_GET['page'];
} else {
   $page = 1;
}
// echo $page; //error change page number

// determine the sql LIMIT starting number for the results on the displaying page
$this_page_first_result = ($_SESSION['page']-1)*$results_per_page;

// echo $page;
// echo $this_page_first_result;

// retrieve selected results from database and display them on page
$sql='SELECT * FROM  personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id LIMIT ' . $this_page_first_result . ',' . $results_per_page;
// echo $sql; //error check limit
$result = mysqli_query($conn, $sql);


// echo $sql;  //checking limit

	
 echo '<table id="list">
	    <thead>
            <tr>
				<th><input type="checkbox"></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<th>Adress 1</th>
				<th>Adress 2</th>
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
       <tbody id="tabledata">';
        while($row = mysqli_fetch_array($result)) {
        echo' 	
		     <tr>
		    	<td><input type="checkbox"></td>
			    <td>'.$row["first_name"].'</td>
		   		<td>'.$row["last_name"].'</td>
		   		<td>'.$row["email"].'</td>  	
		   		<td>'.$row["gender"].'</td>
		   		<td>'.$row["mobile_no"].'</td>
		   		<td>'.$row["addr1"].'</td> 
		   		<td>'.$row["addr2"].'</td>
		   		<td>'.$row["country_name"].'</td>
		   		<td>'.$row["state_name"].'</td> 
		   		<td>'.$row["city"].'</td>
		   		<td>'.$row["pincode"].'</td>
		   		<td><a href=" personal_detail.php?id= '.$row['id'].' "><img src="edit.png" height="20px" width="20px"></a></td>
		   		<td><img src="delete.png" height="20px" width="20px"></td>
		    </tr> ';}
echo' </tbody> </table>';

echo      ' <div class="pagediv">';
				for ($page=1;$page<=$number_of_pages;$page++) {
				  echo '<a class="pagelist" href="index.php?page=' . $page . '">' . $page . '</a> ';
				}	

	 echo  '</div>';




	 ///////////

//        $sqlquery="SELECT * from personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id";
// 	   $query = "
//   SELECT * FROM '"$sqlquery"'
//   ";
//   $statement = $connect->prepare($query);
//   $statement->execute();
//   return $statement->rowCount();
// }

// $total_record = get_total_row($connect);*/

// $limit = '5';
// $page = 1;
// if($_POST['page'] > 1)
// {
//   $start = (($_POST['page'] - 1) * $limit);
//   $page = $_POST['page'];
// }
// else
// {
//   $start = 0;
// }

// $query = "
// SELECT * FROM '"$sqlquery"'
// ";

// if($_POST['query'] != '')
// {
//   $query .= '
//   WHERE webslesson_post_title LIKE "%'.str_replace(' ', '%', $_POST['query']).'%" 
//   ';
// }

// $query .= 'ORDER BY webslesson_post_id ASC ';

// $filter_query = $query . 'LIMIT '.$start.', '.$limit.'';

// $statement = $connect->prepare($query);
// $statement->execute();
// $total_data = $statement->rowCount();

// $statement = $connect->prepare($filter_query);
// $statement->execute();
// $result = $statement->fetchAll();
// $total_filter_data = $statement->rowCount();

// $output = '
// <label>Total Records - '.$total_data.'</label>
// <table class="table table-striped table-bordered">
//   <tr>
//     <th>ID</th>
//     <th>Post Title</th>
//   </tr>
// ';
// if($total_data > 0)
// {
//   foreach($result as $row)
//   {
//     $output .= '
//     <tr>
//       <td>'.$row["webslesson_post_id"].'</td>
//       <td>'.$row["webslesson_post_title"].'</td>
//     </tr>
//     ';
//   }
// }
// else
// {
//   $output .= '
//   <tr>
//     <td colspan="2" align="center">No Data Found</td>
//   </tr>
//   ';
// }

// $output .= '
// </table>
// <br />
// <div align="center">
//   <ul class="pagination">
// ';

// $total_links = ceil($total_data/$limit);
// $previous_link = '';
// $next_link = '';
// $page_link = '';

// //echo $total_links;

// if($total_links > 4)
// {
//   if($page < 5)
//   {
//     for($count = 1; $count <= 5; $count++)
//     {
//       $page_array[] = $count;
//     }
//     $page_array[] = '...';
//     $page_array[] = $total_links;
//   }
//   else
//   {
//     $end_limit = $total_links - 5;
//     if($page > $end_limit)
//     {
//       $page_array[] = 1;
//       $page_array[] = '...';
//       for($count = $end_limit; $count <= $total_links; $count++)
//       {
//         $page_array[] = $count;
//       }
//     }
//     else
//     {
//       $page_array[] = 1;
//       $page_array[] = '...';
//       for($count = $page - 1; $count <= $page + 1; $count++)
//       {
//         $page_array[] = $count;
//       }
//       $page_array[] = '...';
//       $page_array[] = $total_links;
//     }
//   }
// }
// else
// {
//   for($count = 1; $count <= $total_links; $count++)
//   {
//     $page_array[] = $count;
//   }
// }

// for($count = 0; $count < count($page_array); $count++)
// {
//   if($page == $page_array[$count])
//   {
//     $page_link .= '
//     <li class="page-item active">
//       <a class="page-link" href="#">'.$page_array[$count].' <span class="sr-only">(current)</span></a>
//     </li>
//     ';

//     $previous_id = $page_array[$count] - 1;
//     if($previous_id > 0)
//     {
//       $previous_link = '<li class="page-item"><a class="page-link" href="javascript:void(0)" data-page_number="'.$previous_id.'">Previous</a></li>';
//     }
//     else
//     {
//       $previous_link = '
//       <li class="page-item disabled">
//         <a class="page-link" href="#">Previous</a>
//       </li>
//       ';
//     }
//     $next_id = $page_array[$count] + 1;
//     if($next_id >= $total_links)
//     {
//       $next_link = '
//       <li class="page-item disabled">
//         <a class="page-link" href="#">Next</a>
//       </li>
//         ';
//     }
//     else
//     {
//       $next_link = '<li class="page-item"><a class="page-link" href="javascript:void(0)" data-page_number="'.$next_id.'">Next</a></li>';
//     }
//   }
//   else
//   {
//     if($page_array[$count] == '...')
//     {
//       $page_link .= '
//       <li class="page-item disabled">
//           <a class="page-link" href="#">...</a>
//       </li>
//       ';
//     }
//     else
//     {
//       $page_link .= '
//       <li class="page-item"><a class="page-link" href="javascript:void(0)" data-page_number="'.$page_array[$count].'">'.$page_array[$count].'</a></li>
//       ';
//     }
//   }
// }

// $output .= $previous_link . $page_link . $next_link;
// $output .= '
//   </ul>

// </div>
// ';

// echo $output;

 ?>
